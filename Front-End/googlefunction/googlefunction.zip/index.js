/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */
 function checkRecipe(content) {
    // [START automl_language_text_classification_predict]
    /**
     * TODO(developer): Uncomment these variables before running the sample.
     */
    const projectId = 'serverlessproject-320719';
    const location = 'us-central1';
    const modelId = 'TCN4971716702896128000';
  
    // Imports the Google Cloud AutoML library
    const {PredictionServiceClient} = require('@google-cloud/automl').v1;
  
    const client = new PredictionServiceClient();
  
    async function predict() {
      console.log("predict")
      const request = {
        name: client.modelPath(projectId, location, modelId),
        payload: {
          textSnippet: {
            content: content,
            mimeType: 'text/plain', // Types: 'test/plain', 'text/html'
          },
        },
      };
  
      console.log("call predict")
      const [response] = await client.predict(request);
  
      for (const annotationPayload of response.payload) {
        console.log(`Predicted class name: ${annotationPayload.displayName}`);
        console.log(
          `Predicted class score: ${annotationPayload.classification.score}`
        );
      }
  
      return response
    }
  
    predict();
  }
  
  
  exports.helloWorld = (req, res) => {
    let message = req.body.message;
    var response = checkRecipe(message);
  
    res.status(200).send(response);
  };
  